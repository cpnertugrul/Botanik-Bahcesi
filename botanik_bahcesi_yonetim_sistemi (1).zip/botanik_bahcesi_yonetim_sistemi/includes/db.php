    <?php
$servername = "localhost";
$username = "ertu_root";
$password = "hzqaHwdGP%8q7d*j";
$dbname = "ertu_botanik";

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    echo "Bağlantı hatası: " . $e->getMessage();
}
?>
