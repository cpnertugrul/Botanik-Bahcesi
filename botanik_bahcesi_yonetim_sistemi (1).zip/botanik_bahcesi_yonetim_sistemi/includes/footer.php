<footer class="footer mt-auto py-3 bg-light">
    <div class="container">
        <span class="text-muted">© 2024 Botanik Bahçesi Yönetim Sistemi</span>
        <a href="https://github.com/cpnertugrul/Botanik-Bahcesi" target="_blank" class="btn btn-sm btn-outline-secondary">GitHub</a> 
    </div>
</footer>
