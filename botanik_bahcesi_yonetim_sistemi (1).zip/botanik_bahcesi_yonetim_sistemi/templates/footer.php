<div class="footer">
    <p>&copy; 2024 Botanik Bahçesi Yönetim Sistemi. Tüm hakları saklıdır.</p>
</div>
